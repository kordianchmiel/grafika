#include "imagewidget.h"
#include <QPainter >
#include <QKeyEvent >
#include <cmath>
#include <QImage>

using namespace std;

ImageWidget :: ImageWidget (QWidget* parent) : QWidget(parent){
    image = QImage("Lenna.png");
    resultImage = image;
    bright = 0;
}

void ImageWidget :: paintEvent ( QPaintEvent *){
    QPainter painter(this);
    painter. drawImage (0, 0, resultImage );
}

void ImageWidget :: processImage (){
}

void ImageWidget :: keyPressEvent ( QKeyEvent * e){
    if(e->key ()==Qt:: Key_L){                              //linia bresenhama
        int x0 = 100;
        int y0 = 100;
        int x1 = 300;
        int y1 = 200;
        int x=x0;
        int y=y0;

        int dx=x1-x0;
        int dy=y1-y0;
        int dp=2*dy;
        int dd=2*(dy-dx);
        int d=2*dy-dx;

        while(y<y1){
            QRgb* pd = (QRgb *) resultImage .scanLine (y);
            QRgb* ps = (QRgb *) image.scanLine (y);
            x+=1;
            if (d >= 0){
                d+=dd;
                y+=1;
            }
            else{
                d+=dp;
            }
            pd[x] = qRgba(0,0,0,qAlpha(ps[x]));
        }

    }

    if(e->key ()==Qt:: Key_O){                                  //okrag bresenhama
        int r=100;                                              //promien
        int a=150;                                              //wspolrzedna x srodka
        int b=150;                                              //wspolrzedna y srodka
        int x0 = 0+a;
        int y0 = r+b;

        int x=x0;
        int y=y0;

        int d=5-4*r;
        int da=(-2*r+5)*4;
        int db=3*4;

        for(;x<y;){
            QRgb* pd = (QRgb *) resultImage.scanLine(y);
            QRgb* ps = (QRgb *) image.scanLine(y);
            pd[x] = qRgba(0,0,0,qAlpha(ps[x]));
            pd[x] = qRgba(0,0,0,qAlpha(ps[x+x0]));

//            image.setPixelColor(x+x0, y+y0, QColor(0,0,0,0));
//            image.setPixelColor(y+x0, x+y0, QColor(0,0,0,0));
//            image.setPixelColor(y+x0, -x+y0, QColor(0,0,0,0));
//            image.setPixelColor(x+x0, -y+y0, QColor(0,0,0,0));
//            image.setPixelColor(-y+x0, -x+y0, QColor(0,0,0,0));
//            image.setPixelColor(-x+x0, -y+y0, QColor(0,0,0,0));
//            image.setPixelColor(-y+x0, x+y0, QColor(0,0,0,0));
//            image.setPixelColor(-x+x0, y+y0, QColor(0,0,0,0));

            if(d>0){
                d+=da;
                y-=1;
                x+=1;
                da+=4*4;
                db+=2*4;
            }
            else{
                d+=db;
                x+=1;
                da+=2*4;
                db+=2*4;
            }
        }
    }
    if(e->key ()==Qt:: Key_G){                                          //gradient
        for(int y=0; y<image.height (); y++){
            QRgb* pd = (QRgb *) resultImage .scanLine (y);
            QRgb* ps = (QRgb *) image.scanLine (y);
            int n=image.width();                                        //ilosc krokow
            int m=image.width()/n;
            int cpr=000;                                    //kolor gradientu poczatkowy red
            int cpg=255;                                    //kolor gradientu poczatkowy green
            int cpb=000;                                    //kolor gradientu poczatkowy blue
            int ckr=000;                                    //kolor gradientu koncowy red
            int ckg=000;                                    //kolor gradientu koncowy green
            int ckb=255;                                    //kolor gradientu koncowy blue
            for(int x=0; x<image.width(); x++){
                int r = cpr+(ckr-cpr)*(x-x%m)/image.width();
                int g = cpg+(ckg-cpg)*(x-x%m)/image.width();
                int b = cpb+(ckb-cpb)*(x-x%m)/image.width();
                pd[x] = qRgba(r,g,b,qAlpha(ps[x]));

            }
        }
    }
    if(e->key ()==Qt:: Key_T){                              //translacja
        int tx=5;                                           //przesuniecie w poziomie
        int ty=50;                                           //przesuniecie w pionie
        for(int y=0; y<image.width (); y++){
            for(int x=0; x<image.width (); x++){
                int vec2[3]={(x+tx),(y+ty),1};
                if(vec2[0]<=image.width()&&vec2[1]<=image.width()){
                    resultImage.setPixelColor(vec2[0],vec2[1],image.pixelColor(x,y));}

            }
        }
    }
    if(e->key ()==Qt:: Key_R){                              //rotacja
        float kat = 1;                   //kat w radianach
        float cs = cos(kat);
        float si = sin(kat);
        for(int y=0; y<image.width (); y++){
            for(int x=0; x<image.width (); x++){
                //int vec[3]={x,y,1};

                int vec2[3]={(x*cs-si*y),(x*si+y*cs),1};
                if(vec2[0]<=image.width()&&vec2[1]<=image.width()){
                    resultImage.setPixelColor(vec2[0],vec2[1],image.pixelColor(x,y));}
            }
        }
    }
    if(e->key ()==Qt:: Key_S){                              //skalowanie
        float sx=0.5, sy=0.75;                              //wspolczynniki skalowania

        for(int y=0; y<image.width (); y++){
            for(int x=0; x<image.width (); x++){
                //int vec[3]={x,y,1};

                int vec2[3]={(x*sx),(y*sy),1};
                resultImage.setPixelColor(vec2[0],vec2[1],image.pixelColor(x,y));
            }
        }
    }
    if(e->key ()==Qt:: Key_P){                              //pochylenie
        float ax=0.1,ay=0.1;                                      //wspolczynniki
//        int macierzP[3][3]={{1,ay,0},{ax,1,0},{0,0,1}};

        for(int y=0; y<image.width (); y++){
            for(int x=0; x<image.width (); x++){
                //int vec[3]={x,y,1};

                int vec2[3]={(x+ax*y),(x*ay+y),1};
                resultImage.setPixelColor(vec2[0],vec2[1],image.pixelColor(x,y));
            }
        }


    }
    if(e->key ()==Qt:: Key_W){                              //wypelnianie obszaru o zadanym kolorze

        int r = 0;                                          //pierwotny kolor red
        int g = 0;                                          //pierwotny kolor green
        int b = 0;                                          //pierwotny kolor blue
        int r1 = 100;                                          //zadany kolor red
        int g1 = 000;                                          //zadany kolor green
        int b1 = 000;                                          //zadany kolor blue

        for(int i=0; i<image.width(); i++){
            QRgb* pd = (QRgb *) resultImage .scanLine (i);
            QRgb* ps = (QRgb *) image.scanLine (i);
            for(int j=0; j<image.height(); j++){
                if(pd[j] == qRgba(r,g,b,qAlpha(ps[j]))){
                    pd[j] = qRgba(r1,g1,b1,qAlpha(ps[j]));
                }
            }
        }
    }
    if(e->key ()==Qt:: Key_B){                              //krzywe bezier

        int x0 = 0;                                          //punkty kontrolne
        int y0 = 0;                                          //
        int x1 = 0;                                          //
        int y1 = 100;                                          //
        int x2 = 000;                                          //
        int y2 = 000;                                          //
        int x3 = 000;                                          //
        int y3 = 000;                                          //

//        for(int i=0; i<image.width(); i++){
//            QRgb* pd = (QRgb *) resultImage .scanLine (i);
//            QRgb* ps = (QRgb *) image.scanLine (i);
//            for(int j=0; j<image.height(); j++){
//                if(){
//                    pd[j] = qRgba(0,0,0,qAlpha(ps[j]));
//                }
//            }
//        }
    }
    update ();
}
