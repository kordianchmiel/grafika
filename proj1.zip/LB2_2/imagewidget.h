#include <QWidget >
#include <QImage >

class ImageWidget : public QWidget{
    QImage image;
    QImage resultImage ;
    int bright;
    void processImage ();
protected:
    virtual void keyPressEvent ( QKeyEvent *);
    virtual void paintEvent ( QPaintEvent *);
public:
    ImageWidget (QWidget *parent =0);
};
