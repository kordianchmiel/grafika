#include <QApplication >
#include "imagewidget.h"

int main(int argc , char* argv []){
    QApplication app(argc , argv);
    ImageWidget iw;
    iw.show ();
    app.exec ();
}
