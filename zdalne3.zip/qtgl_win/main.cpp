#define GLEW_STATIC
//#define GLEW_NO_GLU
#include "GL/glew.h"

#include <QApplication>
#include <QGLWidget>
#include <QTimer>
#include <QKeyEvent>

typedef GLfloat vec3f[3];

QImage image = QImage("noise_simplex-1024x1024.png");


class Widget : public QGLWidget
{
    GLfloat rtri = 0.0f;

    GLfloat xpos = 0;
    GLfloat ypos = 0;
    GLfloat zpos = 0;

    GLfloat yrot = 0;
    float speed = 2.05f;

protected:
    float getAt(int x, int z) {
        return qRed(image.pixel(x, z))/2.0f;
    }

    void initializeGL()
    {
        GLenum err = glewInit();
        if (GLEW_OK != err)
        {
            qDebug((const char*)glewGetErrorString(err));
        }
        else
        {
            glEnable(GL_DEPTH_TEST);//włączenie testu głębokości
            glEnable(GL_LIGHTING);//wlaczenie oswietlenia
        }

        QTimer *timer = new QTimer(this);
        connect(timer, SIGNAL(timeout()), this, SLOT(update()));
        timer->start(0.066666);
    }

    void paintGL()
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//czyszczenie buforow
        glMatrixMode(GL_PROJECTION);//macierz projekcji
        glLoadIdentity();//macierz jednostkowa
        gluPerspective(65,1,0.1,200);//field of view, aspect, near, far
        glMatrixMode(GL_MODELVIEW);//macierz model widok

        GLfloat xtrans = -xpos;
        GLfloat ytrans = ypos;
        GLfloat ztrans = -zpos;
        GLfloat sceneroty = 360.0f - yrot;

        glLoadIdentity();//macierz jednostkowa
        glRotatef(sceneroty, 0.0f, 1.0f, 0.0f);//rotacja y kamery
        glTranslatef(xtrans, ytrans, ztrans);//translacja x, y, z kamery

        glColor3f(1.0f, 1.0f, 1.0f);//bialy kolor
        //siatka
        int wDol=100;
        glBegin(GL_LINES);
        for (int x = -512;x < 512;x++) {
            for (int z = -512;z < 511;z++) {
                glVertex3f(x, getAt(x+512, z + 512)-wDol, z);
                glVertex3f(x, getAt(x+512, z+1 + 512)-wDol, z+1);
            }
        }
        glEnd();
        glBegin(GL_LINES);
        for (int z = -512;z < 512;z++) {
            for (int x = -512;x < 511;x++) {
                glVertex3f(x, getAt(x+512, z+512)-wDol, z);
                glVertex3f(x+1, getAt(x+512+1, z+512)-wDol, z);
            }
        }
        glEnd();
//      glBegin(GL_);
//      for (int x = -512;x < 512;x++) {
//          for (int z = -512;z < 511;z++) {
//              glNormal3f(x, getAt(x+512, z + 512)-wDol, z);
//              glNormal3f(x, getAt(x+512, z+1 + 512)-wDol, z+1);
//          }
//      }
//      glEnd();
//      glBegin(GL_);
//      for (int z = -512;z < 512;z++) {
//          for (int x = -512;x < 511;x++) {
//              glNormal3f(x, getAt(x+512, z+512)-wDol, z);
//              glNormal3f(x+1, getAt(x+512+1, z+512)-wDol, z);
//          }
//      }
//      glEnd();

        //rotaccja trójkąta
        rtri+=2.0f;
        if(rtri>=360.0)
            rtri = 0.0f;


    }

    void resizeGL(int w, int h)
    {
        glViewport(0,0,w,h);
    }

    void keyPressEvent(QKeyEvent *event) {
        double rad;
        switch (event->key()) {
        case Qt::Key_Escape:
            close();
            break;
        case Qt::Key_F1:
            setWindowState(windowState() ^ Qt::WindowFullScreen);
            break;
        default:
            QGLWidget::keyPressEvent(event);
        case Qt::Key_D:
            rad = yrot*3.141592/180;
            zpos -= speed * sin(rad);
            xpos += speed * cos(rad);
            break;
        case Qt::Key_A:
            rad = yrot*3.141592/180;
            zpos += speed * sin(rad);
            xpos -= speed * cos(rad);
            break;
        case Qt::Key_S:
            rad = (yrot + 90)*3.141592/180;
            zpos += speed * sin(rad);
            xpos -= speed * cos(rad);
            break;
        case Qt::Key_W:
            rad = (yrot + 90)*3.141592/180;
            zpos -= speed * sin(rad);
            xpos += speed * cos(rad);
            break;
        case Qt::Key_Q:
            yrot+=2;
            break;
        case Qt::Key_E:
            yrot-=2;
            break;

        }
    }
};

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    Widget w;
    w.show();
    return app.exec();
}
