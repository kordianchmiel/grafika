#define GLEW_STATIC
//#define GLEW_NO_GLU
#include "GL/glew.h"

#include <QApplication>
#include <QGLWidget>
#include <QTimer>
#include <QKeyEvent>

typedef GLfloat vec3f[3];

class Widget : public QGLWidget
{
    GLfloat rtri = 0.0f;

    GLfloat xpos = 0;
    GLfloat ypos = 0;
    GLfloat zpos = 0;

    GLfloat yrot = 0;
    float speed = 0.05f;

protected:
    void initializeGL()
    {
        GLenum err = glewInit();
        if (GLEW_OK != err)
        {
            qDebug((const char*)glewGetErrorString(err));
        }
        else
        {
            glEnable(GL_DEPTH_TEST);//włączenie testu głębokości
        }

        QTimer *timer = new QTimer(this);
        connect(timer, SIGNAL(timeout()), this, SLOT(update()));
        timer->start(16.66666);//60fps master race
    }

    void paintGL()
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);//czyszczenie buforow
        glMatrixMode(GL_PROJECTION);//macierz projekcji
        glLoadIdentity();//macierz jednostkowa
        gluPerspective(65,1,0.1,100);//field of view, aspect, near, far
        glMatrixMode(GL_MODELVIEW);//macierz model widok

        GLfloat xtrans = -xpos;
        GLfloat ytrans = ypos;
        GLfloat ztrans = -zpos;
        GLfloat sceneroty = 360.0f - yrot;

        glLoadIdentity();//macierz jednostkowa
        glRotatef(sceneroty, 0.0f, 1.0f, 0.0f);//rotacja y kamery
        glTranslatef(xtrans, ytrans, ztrans);//translacja x, y, z kamery

        glPushMatrix();//macierz na stacka

        glTranslatef(0, 0, -3.0);//trójkąt 3 w przód
        glRotatef(rtri, 1.0f, 1.0f, 0.0f);//rotacja wzgledem osi x i y trójkąta
        glBegin(GL_TRIANGLES);
            glColor3f(1.0f,0.0f,0.0f);
            glVertex3f( 0.0f, 1.0f, 0.0f);
            glColor3f(0.0f,1.0f,0.0f);
            glVertex3f( -1.0f, -1.0f, 0.0f);
            glColor3f(0.0f,0.0f,1.0f);
            glVertex3f( 1.0f, -1.0f, 0.0f);
        glEnd();
        glPopMatrix();//macierz ze stacka
        glColor3f(1.0f, 0.0f, 1.0f);//rozowy kolor
        //siatka
        for (int x = -50;x < 50;x++) {
            glBegin(GL_LINE_LOOP);
            glVertex3f(x, -1, -50);
            glVertex3f(x, -1, 50);
            glEnd();
        }
        for (int z = -50;z < 50;z++) {
            glBegin(GL_LINE_LOOP);
            glVertex3f(-50, -1, z);
            glVertex3f(50, -1, z);
            glEnd();
        }
        //rotaccja trójkąta
        rtri+=2.0f;
        if(rtri>=360.0)
            rtri = 0.0f;


    }

    void resizeGL(int w, int h)
    {
        glViewport(0,0,w,h);
    }

    void keyPressEvent(QKeyEvent *event) {
        double rad;
        switch (event->key()) {
        case Qt::Key_Escape:
            close();
            break;
        case Qt::Key_F1:
            setWindowState(windowState() ^ Qt::WindowFullScreen);
            break;
        default:
            QGLWidget::keyPressEvent(event);
        case Qt::Key_D:
            rad = yrot*3.141592/180;
            zpos -= speed * sin(rad);
            xpos += speed * cos(rad);
            break;
        case Qt::Key_A:
            rad = yrot*3.141592/180;
            zpos += speed * sin(rad);
            xpos -= speed * cos(rad);
            break;
        case Qt::Key_S:
            rad = (yrot + 90)*3.141592/180;
            zpos += speed * sin(rad);
            xpos -= speed * cos(rad);
            break;
        case Qt::Key_W:
            rad = (yrot + 90)*3.141592/180;
            zpos -= speed * sin(rad);
            xpos += speed * cos(rad);
            break;
        case Qt::Key_Q:
            yrot+=2;
            break;
        case Qt::Key_E:
            yrot-=2;
            break;

        }
    }
};

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    Widget w;
    w.show();
    return app.exec();
}
